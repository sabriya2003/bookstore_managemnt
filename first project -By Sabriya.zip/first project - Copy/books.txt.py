[
    {
        "Title": "Himu",
        "Author": "Humayun Ahmed",
        "ISBN": "978-1234567890",
        "Genre": "Fiction",
        "Price": 350,
        "Quantity": 15
    },
    {
        "Title": "Dewyal",
        "Author": "Humayun Ahmed",
        "ISBN": "978-0987654321",
        "Genre": "Fiction",
        "Price": 400,
        "Quantity": 10
    },
    {
        "Title": "Ami",
        "Author": "Humayun Ahmed",
        "ISBN": "978-1122334455",
        "Genre": "Fiction",
        "Price": 450,
        "Quantity": 5
    }
]
