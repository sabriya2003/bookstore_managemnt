from book_data import load_books, save_books


def add_book():
    books = load_books()

    title = input("Enter the book title: ")
    author = input("Enter the author: ")
    isbn = input("Enter ISBN: ")
    genre = input("Enter genre: ")
    try:
        price = float(input("Enter the price: "))
        if price <= 0:
            raise ValueError("Price must be a positive number.")
    except ValueError as e:
        print(f"Error: {e}")
        return
    try:
        quantity = int(input("Enter quantity in stock: "))
        if quantity < 0:
            raise ValueError("Quantity must be a non-negative integer.")
    except ValueError as e:
        print(f"Error: {e}")
        return

    # Prevent duplicate ISBNs
    for book in books:
        if book['ISBN'] == isbn:
            print("Error: This ISBN already exists.")
            return

    new_book = {
        'Title': title,
        'Author': author,
        'ISBN': isbn,
        'Genre': genre,
        'Price': price,
        'Quantity': quantity
    }
    books.append(new_book)
    save_books(books)
    print("Book added successfully!")
