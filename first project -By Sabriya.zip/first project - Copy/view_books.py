from book_data import load_books


def view_books():
    books = load_books()
    if not books:
        print("No books available.")
        return

    print("\nAll Available Books:")
    print(f"{'Title':<20} {'Author':<20} {'ISBN':<15} {'Genre':<10} {'Price':<7} {'Stock':<6}")
    print("-" * 80)
    for book in books:
        print(
            f"{book['Title']:<20} {book['Author']:<20} {book['ISBN']:<15} {book['Genre']:<10} {book['Price']:<7} {book['Quantity']:<6}")

