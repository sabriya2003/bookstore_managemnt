from add_book import add_book
from view_books import view_books
from delete_book import delete_book


def main():
    while True:
        print("\nWelcome to the Book Store Management System")
        print("1. Add Book")
        print("2. View Books")
        print("3. Remove Book")
        print("4. Exit")

        choice = input("Choose an option: ")

        if choice == '1':
            add_book()
        elif choice == '2':
            view_books()
        elif choice == '3':
            delete_book()
        elif choice == '4':
            print("Exiting program...")
            break
        else:

            print("Invalid option. Please try again.")


if __name__ == "__main__":
    main()