from book_data import load_books, save_books


def delete_book():
    books = load_books()
    isbn = input("Enter ISBN or Book ID to delete: ")

    for book in books:
        if book['ISBN'] == isbn:
            books.remove(book)
            save_books(books)
            print(f"Book with ISBN {isbn} has been deleted.")
            return
    print("Book not found.")
